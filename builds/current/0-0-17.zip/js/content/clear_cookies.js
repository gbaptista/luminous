Cookies.remove('le', { path: '/' });
Cookies.remove('ld', { path: '/' });
Cookies.remove('ls', { path: '/' });
