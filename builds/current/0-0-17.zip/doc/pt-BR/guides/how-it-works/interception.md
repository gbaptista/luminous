> *Se você encontrar informações faltando ou erros em alguma das traduções, nos ajude abrindo um [pull request](https://github.com/gbaptista/luminous/pulls) com as modificações necessárias nos textos para que todos tenham acesso aos guias em seu idioma.*

# Guias
> [voltar ao índice](../)

## Interceptação

> [en-US](../../../en-US/guides/how-it-works/interception.md) | [es](../../../es/guides/how-it-works/interception.md) | pt-BR

Tradução pendente.
