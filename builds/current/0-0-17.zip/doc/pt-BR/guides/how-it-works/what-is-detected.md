> *Se você encontrar informações faltando ou erros em alguma das traduções, nos ajude abrindo um [pull request](https://github.com/gbaptista/luminous/pulls) com as modificações necessárias nos textos para que todos tenham acesso aos guias em seu idioma.*

# Guias
> [voltar ao índice](../)

## O que é detectado?

> [en-US](../../../en-US/guides/how-it-works/what-is-detected.md) | [es](../../../es/guides/how-it-works/what-is-detected.md) | pt-BR

Tradução pendente.
