> *Se você encontrar informações faltando ou erros em alguma das traduções, nos ajude abrindo um [pull request](https://github.com/gbaptista/luminous/pulls) com as modificações necessárias nos textos para que todos tenham acesso aos guias em seu idioma.*

## Guias
> [voltar ao índice](../)

### Discussões interessantes
> [en-US](../../../en-US/guides/context/interesting-discussions.md) | [es](../../../es/guides/context/interesting-discussions.md) | pt-BR

- [*heads up: Luminous: JavaScript events blocker*](https://github.com/ghacksuserjs/ghacks-user.js/issues/348)
- [*is this meant to be a blocker?*](https://github.com/gbaptista/luminous/issues/18)
