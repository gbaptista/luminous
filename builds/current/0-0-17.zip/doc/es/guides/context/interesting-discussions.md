> *Si encuentra información que falta o errores en alguna de las traducciones, nos ayude abriendo un [pull request](https://github.com/gbaptista/luminous/pulls) con las modificaciones necesarias en los textos para que todos tengan acceso a las guías en su idioma.*

# Guías
> [volver al índice](../)

### Discusiones interesantes
> [en-US](../../../en-US/guides/context/interesting-discussions.md) | es | [pt-BR](../../../pt-BR/guides/context/interesting-discussions.md)

- [*heads up: Luminous: JavaScript events blocker*](https://github.com/ghacksuserjs/ghacks-user.js/issues/348)
- [*is this meant to be a blocker?*](https://github.com/gbaptista/luminous/issues/18)
