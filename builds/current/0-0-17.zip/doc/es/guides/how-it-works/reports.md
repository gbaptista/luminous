> *Si encuentra información que falta o errores en alguna de las traducciones, nos ayude abriendo un [pull request](https://github.com/gbaptista/luminous/pulls) con las modificaciones necesarias en los textos para que todos tengan acceso a las guías en su idioma.*

# Guías
> [volver al índice](../)

## Informes
> [en-US](../../../en-US/guides/how-it-works/reports.md) | es | [pt-BR](../../../pt-BR/guides/how-it-works/reports.md)

Traducción pendiente.
