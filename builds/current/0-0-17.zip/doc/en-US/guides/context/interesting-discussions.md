> *If you find some missing information or errors in any of the translations, help us by opening a [pull request](https://github.com/gbaptista/luminous/pulls) with the necessary modifications in the texts.*

## Guides
> [back to index](../)

### Interesting discussions
> en-US | [es](../../../es/guides/context/interesting-discussions.md) | [pt-BR](../../../pt-BR/guides/context/interesting-discussions.md)

- [*heads up: Luminous: JavaScript events blocker*](https://github.com/ghacksuserjs/ghacks-user.js/issues/348)
- [*is this meant to be a blocker?*](https://github.com/gbaptista/luminous/issues/18)
