chrome.devtools.panels.create(
	'Luminous',
	'../../images/icons/16.png',
	'../../html/logs/logs.html?container=devtools',
	function(_panel) { }
);
