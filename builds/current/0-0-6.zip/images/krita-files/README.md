You can download Krita from: [https://krita.org/](https://krita.org/)
