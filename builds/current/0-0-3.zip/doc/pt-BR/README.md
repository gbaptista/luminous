# Luminous: Bloqueador de eventos JavaScript ![Icon](../../images/icons/48.png)

> [en-US](../en-US) | pt-BR

A versão *pt-BR* deste documento encontra-se em: [/README.md](https://gbaptista.github.io/luminous)
