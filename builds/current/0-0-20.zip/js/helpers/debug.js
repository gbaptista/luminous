var start_time = performance.now();
var debug = false;

var debug_log = function(message) {
  if(debug) console.log(message);
}
